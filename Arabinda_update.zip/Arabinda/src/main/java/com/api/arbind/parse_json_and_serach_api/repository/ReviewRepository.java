package com.api.arbind.parse_json_and_serach_api.repository;

import com.api.arbind.parse_json_and_serach_api.model.Review;
import org.springframework.data.repository.CrudRepository;

public interface ReviewRepository extends CrudRepository<Review,String> {
}
