package com.api.arbind.parse_json_and_serach_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParseJsonAndSerachApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
