package com.api.arbind.parse_json_and_serach_api.service;

import com.api.arbind.parse_json_and_serach_api.model.Book;

import java.util.List;
import java.util.Optional;


public interface BookService {
     Optional<Book> findByTitle(String title);

    Iterable<Book> save(List<Book> books);
}
