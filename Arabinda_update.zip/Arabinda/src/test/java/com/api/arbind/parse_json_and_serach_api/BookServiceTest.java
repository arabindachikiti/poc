package com.api.arbind.parse_json_and_serach_api;

import com.api.arbind.parse_json_and_serach_api.model.Book;
import com.api.arbind.parse_json_and_serach_api.repository.BookRepository;
import com.api.arbind.parse_json_and_serach_api.service.BookServiceImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Optional;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.mockito.Mockito.when;


@RunWith(MockitoJUnitRunner.class)
public class BookServiceTest {

    @Mock
    BookRepository bookRepository;

    @InjectMocks
    BookServiceImpl bookService;

    @Test
    public void testFindByTitle() {
        Book b=new Book();
        b.setTitle("SQL book");
        String title="SQL book";
        when(bookRepository.findById(title)).thenReturn(Optional.ofNullable(b));
        assertEquals("SQL book",bookService.findByTitle(title).isPresent() ? bookService.findByTitle(title).get().getTitle() : "");

    }

    @Test
    public void testFindByTitle2() {
        Book b=new Book();
        b.setTitle("Java book");
        String title="Java book";
        when(bookRepository.findById(title)).thenReturn(Optional.ofNullable(b));
        assertNotEquals("Oracle book",bookService.findByTitle(title).isPresent() ? bookService.findByTitle(title).get().getTitle() : "");

    }
}