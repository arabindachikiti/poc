package com.api.arbind.parse_json_and_serach_api.controller;


import com.api.arbind.parse_json_and_serach_api.model.Book;
import com.api.arbind.parse_json_and_serach_api.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

@RestController
@RequestMapping("/searchApi")
public class BookController {

    @Autowired
   private BookService bookService;

    @GetMapping("/bookdetils/{title}")
    public Optional<Book> getBookDetails(@PathVariable("title") String title){
        return bookService.findByTitle(title);

    }
}
