package com.api.arbind.parse_json_and_serach_api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookService {

    @Autowired
    private BookRepository bookRepository;

    public Iterable<Book> save(List<Book> users) {
          return bookRepository.saveAll(users);
      }

    public Optional<Book> findByTitle(String title) {
        return bookRepository.findById(title);
    }
}
