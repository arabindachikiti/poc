package com.api.arbind.parse_json_and_serach_api;

import com.api.arbind.parse_json_and_serach_api.model.Book;
import com.api.arbind.parse_json_and_serach_api.repository.ReviewRepository;
import com.api.arbind.parse_json_and_serach_api.service.BookService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

@SpringBootApplication
public class ParseJsonAndSerachApiApplication {

    @Autowired
    ReviewRepository reviewRepository;
    public static void main(String[] args) {
        SpringApplication.run(ParseJsonAndSerachApiApplication.class, args);
    }

    @Bean
    CommandLineRunner runner(BookService bookService) {
        return args -> {
            // read json and write to db
            ObjectMapper mapper = new ObjectMapper();
            TypeReference<List<Book>> typeReference = new TypeReference<List<Book>>(){};
            InputStream inputStream = TypeReference.class.getResourceAsStream("/json/test.json");
            try {
                List<Book> books = mapper.readValue(inputStream,typeReference);
                bookService.save(books);
               /* for (Book b:books){
                    reviewRepository.saveAll(b.getReviews());
                }*/
                System.out.println("Books Saved!");
            } catch (IOException e){
                System.out.println("Unable to save Books: " + e.getMessage());
            }
        };
    }
}
